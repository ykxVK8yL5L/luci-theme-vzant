"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");

exports.__esModule = true;
exports.default = void 0;

var _vueLazyload = _interopRequireDefault(require("vue-lazyload"));

var _default = _vueLazyload.default;
exports.default = _default;