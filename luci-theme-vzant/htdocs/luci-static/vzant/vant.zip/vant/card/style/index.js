require('../../style/base.css');
require('../../tag/index.css');
require('../../image/index.css');
require('../index.css');