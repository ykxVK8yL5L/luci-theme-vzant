require('../../style/base.less');
require('../../tag/index.less');
require('../../image/index.less');
require('../index.less');