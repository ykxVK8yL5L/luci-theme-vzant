require('../../style/base.css');
require('../../popup/index.css');
require('../../image/index.css');
require('../../swipe/index.css');
require('../../swipe-item/index.css');
require('../index.css');