require('../../style/base.less');
require('../../popup/index.less');
require('../../image/index.less');
require('../../swipe/index.less');
require('../../swipe-item/index.less');
require('../index.less');