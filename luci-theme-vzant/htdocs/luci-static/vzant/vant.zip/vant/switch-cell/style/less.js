require('../../style/base.less');
require('../../image/index.less');
require('../../switch/index.less');
require('../index.less');