require('../../style/base.less');
require('../../image/index.less');
require('../../checkbox/index.less');
require('../index.less');