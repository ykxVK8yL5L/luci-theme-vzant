require('../../style/base.less');
require('../../image/index.less');
require('../../radio/index.less');
require('../index.less');