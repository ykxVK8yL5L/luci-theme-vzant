require('../../style/base.css');
require('../../picker/index.css');