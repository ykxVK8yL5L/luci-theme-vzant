require('../../style/base.less');
require('../../image/index.less');