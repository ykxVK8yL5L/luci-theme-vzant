require('../../style/base.less');
require('../../image/index.less');
require('../../popup/index.less');
require('../../swipe/index.less');
require('../../swipe-item/index.less');
require('../../image-preview/index.less');
require('../index.less');